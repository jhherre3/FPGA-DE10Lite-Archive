module six_digit_timer (
    input wire CLOCK_50,          // 50 MHz clock
    output reg [6:0] HEX0,        // HEX display segments (active-low)
    output reg [6:0] HEX1,
    output reg [6:0] HEX2,
    output reg [6:0] HEX3,
    output reg [6:0] HEX4,
    output reg [6:0] HEX5
);

    // ===== CLOCK DIVIDER FOR 1HZ =====
    reg [25:0] clk_div = 0;
    reg one_sec_tick = 0;

    always @(posedge CLOCK_50) begin
        if (clk_div == 50_000_000 - 1) begin
            clk_div <= 0;
            one_sec_tick <= 1;
        end else begin
            clk_div <= clk_div + 1;
            one_sec_tick <= 0;
        end
    end

    // ===== BCD DIGITS (0–9) =====
    reg [3:0] digit [5:0]; // digit[0] = HEX0, digit[5] = HEX5

    integer i;

    always @(posedge CLOCK_50) begin
        if (one_sec_tick) begin
            // BCD counter increment
            digit[0] <= digit[0] + 1;

            for (i = 0; i < 5; i = i + 1) begin
                if (digit[i] == 10) begin
                    digit[i] <= 0;
                    digit[i+1] <= digit[i+1] + 1;
                end
            end

            // Prevent overflow past 999999
            if (digit[5] == 10)
                digit[5] <= 9;
        end
    end

    // ===== BCD to 7-Segment Decoder =====
    function [6:0] bcd_to_7seg(input [3:0] val);
        case (val)
            4'd0: bcd_to_7seg = 7'b100_0000;
            4'd1: bcd_to_7seg = 7'b111_1001;
            4'd2: bcd_to_7seg = 7'b010_0100;
            4'd3: bcd_to_7seg = 7'b011_0000;
            4'd4: bcd_to_7seg = 7'b001_1001;
            4'd5: bcd_to_7seg = 7'b001_0010;
            4'd6: bcd_to_7seg = 7'b000_0010;
            4'd7: bcd_to_7seg = 7'b111_1000;
            4'd8: bcd_to_7seg = 7'b000_0000;
            4'd9: bcd_to_7seg = 7'b001_0000;
            default: bcd_to_7seg = 7'b111_1111; // blank
        endcase
    endfunction

    always @(*) begin
        HEX0 = bcd_to_7seg(digit[0]);
        HEX1 = bcd_to_7seg(digit[1]);
        HEX2 = bcd_to_7seg(digit[2]);
        HEX3 = bcd_to_7seg(digit[3]);
        HEX4 = bcd_to_7seg(digit[4]);
        HEX5 = bcd_to_7seg(digit[5]);
    end

endmodule
