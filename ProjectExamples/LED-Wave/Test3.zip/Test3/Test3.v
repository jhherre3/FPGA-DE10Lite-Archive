module Test3 (
    input wire CLOCK_50,           // 50 MHz clock
    input wire [9:0] SW,           // Switches
    output reg [9:0] LEDR          // Red LEDs
);

    reg [24:0] counter = 0;
    reg [3:0] position = 0;
    reg dir = 0; // 0 = forward, 1 = reverse

    always @(posedge CLOCK_50) begin
        counter <= counter + 1;

        // ~0.25s delay at 50 MHz
        if (counter >= 12_000_000) begin
            counter <= 0;

            // Read direction from SW[0]
            dir <= SW[0];

            if (dir == 1'b0) begin
                // Forward: 0 → 9
                position <= (position == 9) ? 0 : position + 1;
            end else begin
                // Reverse: 9 → 0
                position <= (position == 0) ? 9 : position - 1;
            end
        end
    end

    always @(*) begin
        LEDR = 10'b0;
        LEDR[position] = 1'b1;
    end

endmodule
